import pygame, os
from pygame.locals import *
import threading, time
import random

pygame.init()
pygame.display.set_caption("Mario VS Choooooooommmppsssssssss !!!")

os.environ['SDL_VIDEO_CENTERED'] = '1'

fenetre = pygame.display.set_mode((1000, 600))
mario = pygame.image.load('mariopetit.png').convert_alpha()
chomp = pygame.image.load('chomp.png').convert_alpha()
fond = pygame.image.load('fond.png').convert()


pygame.mouse.set_visible(False)

chomps = []
x = -1
y = -1

time1 = time.time()

sleep = 1



def create_chomps():
    max_chomps = 20
    global time2
    time2 = time.time()
    if 61 < time2 - time1 < 120:
        max_chomps = 30
    if 121 < time2 - time1 < 180:
        max_chomps = 40
    if 181 < time2 - time1 < 240:
        max_chomps = 50
    if 241 < time2 - time1 < 300:
        max_chomps = 60
    if 301 < time2 - time1:
        max_chomps = 80
        sleep = 0.75
    while not len(chomps) == max_chomps:
        board = random.randint(1,4)
        if board == 1:
            pos_x = 0
            pos_y = random.randint(0,600)
            dep_x = random.randint(10,50)
            dep_y = random.randint(-50,50)
        if board == 3:
            pos_x = 1000
            pos_y = random.randint(0,600)
            dep_x = random.randint(-50,-10)
            dep_y = random.randint(-50,50)
        if board == 2:
            pos_x = random.randint(0,1000)
            pos_y = 0
            dep_x = random.randint(-50,50)
            dep_y = random.randint(10,50)
        if board == 4:
            pos_x = random.randint(0,1000)
            pos_y = 600
            dep_x = random.randint(-50,50)
            dep_y = random.randint(-50,-10)
        chomps.append([pos_x, pos_y, dep_x, dep_y])

continuer = True

def draw_all(incr_chomps):
    ret = True
    fenetre.blit(fond, (0,0))
    i = 0
    while i < len(chomps):
        elem = chomps[i]
        if incr_chomps:
            elem[0] += elem[2]
            elem[1] += elem[3]
            if elem[0] >= 1000 or elem[1] >= 600 or elem[0] < 0 or elem[1] < 0:
                chomps.remove(elem)
                if i > 0:
                    i -= 1
                continue
        if x > elem[0] and x < elem[0] + 55 or x + 50 > elem[0] and x + 50 < elem[0] + 55:
            if y > elem[1] and y < elem[1] + 45 or y + 50 > elem[1] and y + 50 < elem[1] + 45:
                ret = False
                with open("scoreMario.txt", "r") as scoreMario:
                    score = scoreMario.readlines()
                if (len(score) == 0):
                    with open("scoreMario.txt", "w") as scoreMario:
                        scoreMario.write(str(int(time2 - time1)))
                else:                            
                    if (int(score[0]) < int(time2 - time1)):
                        score[0] = int(time2 - time1)
                        with open("scoreMario.txt", "w") as scoreMario:
                            scoreMario.write(str(int(time2 - time1)))
                print("Congratulation ! You survived "+str(int(time2 - time1))+" secondes !\n")
                print("Your best score is: "+str(score[0])+" ! Try to beat it !")
        fenetre.blit(chomp, (elem[0], elem[1]))
        i += 1
    create_chomps()
    fenetre.blit(mario, (x, y))
    pygame.display.flip()
    return ret

def draw_chomps():
    global continuer
    while continuer:
        continuer = draw_all(True)
        time.sleep(sleep)

create_chomps()
threading.Thread(target = draw_chomps).start()

while continuer:
    event = pygame.event.poll()
    if event.type == QUIT:
        continuer = False
    if event.type == MOUSEMOTION:
        x = event.pos[0]
        y = event.pos[1]
        continuer = draw_all(False)

pygame.display.quit()
